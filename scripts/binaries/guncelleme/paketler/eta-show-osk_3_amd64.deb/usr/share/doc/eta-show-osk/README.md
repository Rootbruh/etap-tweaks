# ETA Show OSK

ETA Show OSK is a GNOME Shell extension that shows or hides GNOME's on-screen keyboard. This is created for ETAP project. This is licensed under GPL 3.

**NOTE:** extension.js code is from the On-screen Keyboard Button GNOME shell extension. This is licensed under GPL 2.

**NOTE:** Makefile is from the APT Update Indicator GNOME shell extension. This is licensed under GPL 3.
