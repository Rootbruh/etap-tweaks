# Restart Shell - GNOME Shell Extension

Restrarts the shell via a panel button.

**Author and packager:** Erdem Ersoy

**License:** GPL 3

**NOTE:** Makefile is from the APT Update Indicator GNOME Shell extension. This is licensed under GPL 3.

**NOTE:** extension.js codes from the On Screen Keyboard Button GNOME Shell extension. This is licensed under GPL 2.
