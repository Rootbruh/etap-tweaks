// Restart Shell GNOME Shell Extension main script
// Copyright (C) 2019 Erdem Ersoy
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

const Gio = imports.gi.Gio;
const St = imports.gi.St;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;

var restartMenuButton = null;

const Overview = imports.ui.main.overview;
const ViewSelector = imports.ui.viewSelector;

var RestartMenuButton = class RestartMenuButton extends PanelMenu.Button {

    _init() {
        super._init(0.0, "${Me.metadata.name} Menu Button", false);

        let icon = new St.Icon({
            gicon: new Gio.ThemedIcon({name: "view-refresh"}),
            style_class: "system-status-icon"
        });
        this.actor.add_child(icon);

        // This is Turkish hardcoded currently.
        this.menu.addAction("Yenile", this.menuAction, null);
    }

    menuAction() {
        log("Restarting the shell via Restart Shell GNOME Shell Extension...");
        Overview.viewSelector.showApps();
        Gio.Subprocess.new(["/usr/bin/eta-restart-shell"], 0);
    }
}

function init() {
    log("Initializing ${Me.metadata.name} GNOME Shell Extension");
}

function enable() {
    log("Enabling ${Me.metadata.name} GNOME Shell Extension");

    restartMenuButton = new RestartMenuButton();

    Main.panel.addToStatusArea("${Me.metadata.name} Menu Button", restartMenuButton);
}

function disable() {
    log("Disabling ${Me.metadata.name} GNOME Shell Extension");

    if (restartMenuButton !== null) {
        restartMenuButton.destroy();
        restartMenuButton = null;
    }
}
